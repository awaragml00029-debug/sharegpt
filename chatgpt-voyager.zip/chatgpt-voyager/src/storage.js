(() => {
  'use strict';

  window.CGV = window.CGV || {};

  function now() {
    return Date.now();
  }

  function createDefaultData() {
    return {
      version: 1,
      folders: [],
      folderContents: {}
    };
  }

  function normalizeFolder(raw, index) {
    const id = typeof raw?.id === 'string' ? raw.id : `folder_${now()}_${index}`;
    return {
      id,
      name: typeof raw?.name === 'string' && raw.name.trim() ? raw.name.trim() : 'New Folder',
      parentId: null,
      isExpanded: raw?.isExpanded !== false,
      pinned: raw?.pinned === true,
      color: typeof raw?.color === 'string' ? raw.color : 'default',
      sortIndex: Number.isFinite(raw?.sortIndex) ? raw.sortIndex : index,
      createdAt: Number.isFinite(raw?.createdAt) ? raw.createdAt : now(),
      updatedAt: Number.isFinite(raw?.updatedAt) ? raw.updatedAt : now()
    };
  }

  function normalizeConversation(raw, index) {
    const id = typeof raw?.conversationId === 'string' ? raw.conversationId : '';
    if (!id) return null;

    return {
      conversationId: id,
      title: typeof raw?.title === 'string' && raw.title.trim() ? raw.title.trim() : 'Untitled Conversation',
      url: typeof raw?.url === 'string' && raw.url ? raw.url : `/c/${id}`,
      addedAt: Number.isFinite(raw?.addedAt) ? raw.addedAt : now(),
      updatedAt: Number.isFinite(raw?.updatedAt) ? raw.updatedAt : now(),
      sortIndex: Number.isFinite(raw?.sortIndex) ? raw.sortIndex : index
    };
  }

  function normalizeData(raw) {
    const fallback = createDefaultData();
    if (!raw || typeof raw !== 'object') return fallback;

    const folders = Array.isArray(raw.folders)
      ? raw.folders.map((folder, index) => normalizeFolder(folder, index))
      : [];

    const folderMap = new Map(folders.map((folder) => [folder.id, folder]));
    const folderContents = {};

    const rawContents = raw.folderContents && typeof raw.folderContents === 'object'
      ? raw.folderContents
      : {};

    for (const folder of folders) {
      const list = Array.isArray(rawContents[folder.id]) ? rawContents[folder.id] : [];
      const normalized = list
        .map((item, index) => normalizeConversation(item, index))
        .filter((item) => item !== null);

      const deduped = [];
      const seen = new Set();
      normalized.forEach((item) => {
        if (seen.has(item.conversationId)) return;
        seen.add(item.conversationId);
        deduped.push(item);
      });

      deduped.forEach((item, index) => {
        item.sortIndex = index;
      });

      folderContents[folder.id] = deduped;
    }

    folders.forEach((folder, index) => {
      folder.sortIndex = index;
      folder.updatedAt = Number.isFinite(folder.updatedAt) ? folder.updatedAt : now();
      if (!folderMap.has(folder.id)) {
        folderMap.set(folder.id, folder);
      }
    });

    return {
      version: 1,
      folders,
      folderContents
    };
  }

  function getStorageArea() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return chrome.storage.local;
    }
    return null;
  }

  async function load() {
    const key = window.CGV.constants.storageKey;
    const area = getStorageArea();
    if (!area) return createDefaultData();

    try {
      const result = await area.get([key]);
      return normalizeData(result[key]);
    } catch {
      return createDefaultData();
    }
  }

  async function save(data) {
    const key = window.CGV.constants.storageKey;
    const area = getStorageArea();
    if (!area) return;

    const normalized = normalizeData(data);

    await area.set({ [key]: normalized });
  }

  window.CGV.storage = {
    createDefaultData,
    normalizeData,
    load,
    save
  };
})();
