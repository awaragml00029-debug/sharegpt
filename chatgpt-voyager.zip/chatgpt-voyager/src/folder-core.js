(() => {
  'use strict';

  window.CGV = window.CGV || {};

  function now() {
    return Date.now();
  }

  function createId(prefix) {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return `${prefix}_${window.crypto.randomUUID()}`;
    }
    return `${prefix}_${now()}_${Math.random().toString(16).slice(2)}`;
  }

  function normalizeSortIndexes(items) {
    items.forEach((item, index) => {
      item.sortIndex = index;
      item.updatedAt = now();
    });
  }

  function sortFolders(data) {
    const folders = Array.isArray(data.folders) ? data.folders : [];
    folders.sort((a, b) => {
      const ai = Number.isFinite(a.sortIndex) ? a.sortIndex : Number.MAX_SAFE_INTEGER;
      const bi = Number.isFinite(b.sortIndex) ? b.sortIndex : Number.MAX_SAFE_INTEGER;
      if (ai !== bi) return ai - bi;
      return (a.name || '').localeCompare(b.name || '');
    });
    normalizeSortIndexes(folders);
    return folders;
  }

  function sortConversations(data, folderId) {
    const list = ensureFolderContents(data, folderId);
    list.sort((a, b) => {
      const ai = Number.isFinite(a.sortIndex) ? a.sortIndex : Number.MAX_SAFE_INTEGER;
      const bi = Number.isFinite(b.sortIndex) ? b.sortIndex : Number.MAX_SAFE_INTEGER;
      if (ai !== bi) return ai - bi;
      return (a.title || '').localeCompare(b.title || '');
    });
    normalizeSortIndexes(list);
    return list;
  }

  function ensureFolderContents(data, folderId) {
    if (!data.folderContents || typeof data.folderContents !== 'object') {
      data.folderContents = {};
    }
    if (!Array.isArray(data.folderContents[folderId])) {
      data.folderContents[folderId] = [];
    }
    return data.folderContents[folderId];
  }

  function getFolderById(data, folderId) {
    return (data.folders || []).find((folder) => folder.id === folderId) || null;
  }

  function createFolder(data, partial) {
    const id = createId('folder');
    const folder = {
      id,
      name: typeof partial?.name === 'string' && partial.name.trim() ? partial.name.trim() : 'New Folder',
      parentId: null,
      isExpanded: true,
      pinned: false,
      color: typeof partial?.color === 'string' ? partial.color : 'default',
      sortIndex: (data.folders || []).length,
      createdAt: now(),
      updatedAt: now()
    };

    if (!Array.isArray(data.folders)) {
      data.folders = [];
    }

    data.folders.push(folder);
    ensureFolderContents(data, id);
    sortFolders(data);
    return folder;
  }

  function renameFolder(data, folderId, nextName) {
    const folder = getFolderById(data, folderId);
    if (!folder) return false;

    const name = typeof nextName === 'string' ? nextName.trim() : '';
    if (!name) return false;

    folder.name = name;
    folder.updatedAt = now();
    return true;
  }

  function setFolderColor(data, folderId, color) {
    const folder = getFolderById(data, folderId);
    if (!folder) return false;

    folder.color = typeof color === 'string' && color ? color : 'default';
    folder.updatedAt = now();
    return true;
  }

  function deleteFolder(data, folderId) {
    const folders = Array.isArray(data.folders) ? data.folders : [];
    const nextFolders = folders.filter((folder) => folder.id !== folderId);
    const deleted = nextFolders.length !== folders.length;
    data.folders = nextFolders;

    if (data.folderContents && Object.prototype.hasOwnProperty.call(data.folderContents, folderId)) {
      delete data.folderContents[folderId];
    }

    sortFolders(data);
    return deleted;
  }

  function removeConversationFromAllFolders(data, conversationId) {
    if (!data.folderContents || typeof data.folderContents !== 'object') return;

    Object.keys(data.folderContents).forEach((folderId) => {
      const list = data.folderContents[folderId];
      if (!Array.isArray(list)) return;
      const next = list.filter((item) => item.conversationId !== conversationId);
      data.folderContents[folderId] = next;
      normalizeSortIndexes(next);
    });
  }

  function assignConversationToFolder(data, folderId, conversation, targetIndex) {
    if (!conversation || typeof conversation.conversationId !== 'string' || !conversation.conversationId) {
      return false;
    }

    const folder = getFolderById(data, folderId);
    if (!folder) return false;

    removeConversationFromAllFolders(data, conversation.conversationId);

    const list = ensureFolderContents(data, folderId);
    const item = {
      conversationId: conversation.conversationId,
      title: typeof conversation.title === 'string' && conversation.title.trim() ? conversation.title.trim() : 'Untitled Conversation',
      url:
        typeof conversation.url === 'string' && conversation.url
          ? conversation.url
          : `${window.location.origin}/c/${conversation.conversationId}`,
      addedAt: now(),
      updatedAt: now(),
      sortIndex: list.length
    };

    if (Number.isFinite(targetIndex) && targetIndex >= 0 && targetIndex <= list.length) {
      list.splice(targetIndex, 0, item);
    } else {
      list.push(item);
    }

    normalizeSortIndexes(list);
    return true;
  }

  function removeConversationFromFolder(data, folderId, conversationId) {
    const list = ensureFolderContents(data, folderId);
    const next = list.filter((item) => item.conversationId !== conversationId);
    const changed = next.length !== list.length;
    data.folderContents[folderId] = next;
    normalizeSortIndexes(next);
    return changed;
  }

  function moveConversationBetweenFolders(data, sourceFolderId, targetFolderId, conversationId, targetIndex) {
    const sourceList = ensureFolderContents(data, sourceFolderId);
    const found = sourceList.find((item) => item.conversationId === conversationId);
    if (!found) return false;

    const removed = removeConversationFromFolder(data, sourceFolderId, conversationId);
    if (!removed) return false;

    return assignConversationToFolder(data, targetFolderId, found, targetIndex);
  }

  function reorderFolders(data, draggedFolderId, targetFolderId, placeAfter) {
    const folders = sortFolders(data);
    const fromIndex = folders.findIndex((folder) => folder.id === draggedFolderId);
    const toIndexRaw = folders.findIndex((folder) => folder.id === targetFolderId);
    if (fromIndex < 0 || toIndexRaw < 0 || draggedFolderId === targetFolderId) return false;

    const [dragged] = folders.splice(fromIndex, 1);
    let toIndex = toIndexRaw;
    if (fromIndex < toIndex) {
      toIndex -= 1;
    }
    if (placeAfter) {
      toIndex += 1;
    }
    folders.splice(Math.max(0, Math.min(toIndex, folders.length)), 0, dragged);
    normalizeSortIndexes(folders);
    data.folders = folders;
    return true;
  }

  function reorderConversationWithinFolder(data, folderId, draggedConversationId, targetConversationId, placeAfter) {
    const list = ensureFolderContents(data, folderId);
    const fromIndex = list.findIndex((item) => item.conversationId === draggedConversationId);
    const toIndexRaw = list.findIndex((item) => item.conversationId === targetConversationId);
    if (fromIndex < 0 || toIndexRaw < 0 || draggedConversationId === targetConversationId) return false;

    const [dragged] = list.splice(fromIndex, 1);
    let toIndex = toIndexRaw;
    if (fromIndex < toIndex) {
      toIndex -= 1;
    }
    if (placeAfter) {
      toIndex += 1;
    }
    list.splice(Math.max(0, Math.min(toIndex, list.length)), 0, dragged);
    normalizeSortIndexes(list);
    return true;
  }

  function updateConversationMetadata(data, conversation) {
    if (!conversation || !conversation.conversationId) return;

    Object.keys(data.folderContents || {}).forEach((folderId) => {
      const list = ensureFolderContents(data, folderId);
      const item = list.find((entry) => entry.conversationId === conversation.conversationId);
      if (!item) return;

      if (typeof conversation.title === 'string' && conversation.title.trim()) {
        item.title = conversation.title.trim();
      }
      if (typeof conversation.url === 'string' && conversation.url) {
        item.url = conversation.url;
      }
      item.updatedAt = now();
    });
  }

  window.CGV.core = {
    sortFolders,
    sortConversations,
    ensureFolderContents,
    getFolderById,
    createFolder,
    renameFolder,
    setFolderColor,
    deleteFolder,
    assignConversationToFolder,
    removeConversationFromFolder,
    moveConversationBetweenFolders,
    reorderFolders,
    reorderConversationWithinFolder,
    updateConversationMetadata
  };
})();
