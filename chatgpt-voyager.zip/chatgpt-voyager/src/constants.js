(() => {
  'use strict';

  window.CGV = window.CGV || {};

  window.CGV.constants = {
    storageKey: 'cgv.folderData.v1',
    appRootId: 'cgv-root',
    conversationUrlPattern: /\/c\/([a-zA-Z0-9-]{8,})/,
    folderColors: ['default', 'red', 'orange', 'yellow', 'green', 'blue', 'purple', 'pink'],
    folderColorMap: {
      default: '#6b7280',
      red: '#ef4444',
      orange: '#f97316',
      yellow: '#eab308',
      green: '#22c55e',
      blue: '#3b82f6',
      purple: '#8b5cf6',
      pink: '#ec4899'
    },
    dragTypeConversation: 'cgv/conversation',
    dragTypeFolderConversation: 'cgv/folder-conversation',
    dragTypeFolder: 'cgv/folder',
    maxTitleLength: 120
  };
})();
