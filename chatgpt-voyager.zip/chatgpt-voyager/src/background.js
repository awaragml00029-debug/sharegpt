chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'CGV_EXPORT_OPEN_TAB') {
    return false;
  }

  const targetUrl = typeof message.url === 'string' ? message.url : '';
  if (!targetUrl) {
    sendResponse({ ok: false, error: 'invalid url' });
    return false;
  }

  chrome.tabs.create({ url: targetUrl, active: false }, (tab) => {
    if (chrome.runtime.lastError || !tab || typeof tab.id !== 'number') {
      sendResponse({ ok: false, error: chrome.runtime.lastError?.message || 'tab create failed' });
      return;
    }

    const tabId = tab.id;
    let finished = false;

    const finish = (payload) => {
      if (finished) return;
      finished = true;
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.remove(tabId, () => {
        sendResponse(payload);
      });
    };

    const timeoutId = setTimeout(() => {
      finish({ ok: false, error: 'export tab timeout' });
    }, 15000);

    const onUpdated = (_updatedTabId, info) => {
      if (_updatedTabId !== tabId) return;
      if (info.status !== 'complete') return;

      chrome.scripting.executeScript(
        {
          target: { tabId },
          func: () => {
            const nodes = Array.from(
              document.querySelectorAll('[data-message-author-role="user"], [data-message-author-role="assistant"]')
            );

            return nodes
              .map((node) => {
                const role = node.getAttribute('data-message-author-role') || 'unknown';
                const text = (node.textContent || '').trim();
                if (!text) return null;
                return { role, text };
              })
              .filter((entry) => entry !== null);
          }
        },
        (results) => {
          clearTimeout(timeoutId);

          if (chrome.runtime.lastError) {
            finish({ ok: false, error: chrome.runtime.lastError.message || 'script execution failed' });
            return;
          }

          const content =
            Array.isArray(results) && results[0] && Array.isArray(results[0].result)
              ? results[0].result
              : [];

          finish({ ok: true, content });
        }
      );
    };

    chrome.tabs.onUpdated.addListener(onUpdated);
  });

  return true;
});
