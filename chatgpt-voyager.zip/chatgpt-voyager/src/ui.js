(() => {
  'use strict';

  window.CGV = window.CGV || {};

  function escapeHtml(input) {
    const text = String(input || '');
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function clampTitle(input) {
    const text = String(input || '').trim();
    if (!text) return 'Untitled Conversation';
    return text.slice(0, window.CGV.constants.maxTitleLength);
  }

  function clampFolderName(input) {
    const text = String(input || '').trim();
    if (!text) return null;
    return text.slice(0, 60);
  }

  function createElementFromHTML(html) {
    const template = document.createElement('template');
    template.innerHTML = html.trim();
    return template.content.firstElementChild;
  }

  function getFolderColorHex(colorId) {
    const map = window.CGV.constants.folderColorMap;
    return map[colorId] || map.default;
  }

  function getFolderById(state, folderId) {
    return window.CGV.core.getFolderById(state.data, folderId);
  }

  function saveAndRender(state) {
    return window.CGV.storage.save(state.data).then(() => {
      render(state);
    });
  }

  function folderListSorted(state) {
    return window.CGV.core.sortFolders(state.data);
  }

  function conversationsForFolder(state, folderId) {
    return window.CGV.core.sortConversations(state.data, folderId);
  }

  function setStatus(state, message, isError) {
    if (!state.statusEl) return;
    state.statusEl.textContent = message || '';
    state.statusEl.classList.toggle('cgv-status-error', Boolean(isError));
  }

  function getFolderConversationData(state, folderId, conversationId) {
    const list = window.CGV.core.ensureFolderContents(state.data, folderId);
    return list.find((item) => item.conversationId === conversationId) || null;
  }

  function commitCreateFolder(state, inputEl, colorSelectEl) {
    const normalized = clampFolderName(inputEl?.value || '');
    if (!normalized) {
      setStatus(state, 'Folder name is required.', true);
      return;
    }

    const color =
      colorSelectEl && typeof colorSelectEl.value === 'string' && colorSelectEl.value
        ? colorSelectEl.value
        : 'default';

    window.CGV.core.createFolder(state.data, { name: normalized, color });

    if (inputEl) {
      inputEl.value = '';
    }
    if (colorSelectEl) {
      colorSelectEl.value = 'default';
    }

    saveAndRender(state).then(() => {
      setStatus(state, 'Folder created.');
    });
  }

  function commitRenameFolder(state, folderId, nextName) {
    const normalized = clampFolderName(nextName);
    if (!normalized) {
      setStatus(state, 'Folder name is required.', true);
      return;
    }

    const changed = window.CGV.core.renameFolder(state.data, folderId, normalized);
    if (!changed) {
      setStatus(state, 'Failed to rename folder.', true);
      return;
    }

    state.editingFolderId = null;
    saveAndRender(state).then(() => {
      setStatus(state, 'Folder renamed.');
    });
  }

  function commitDeleteFolder(state, folderId) {
    const folder = getFolderById(state, folderId);
    if (!folder) {
      setStatus(state, 'Folder not found.', true);
      return;
    }

    const changed = window.CGV.core.deleteFolder(state.data, folderId);
    if (!changed) {
      setStatus(state, 'Failed to delete folder.', true);
      return;
    }

    state.deletePendingFolderId = null;
    state.editingFolderId = null;

    saveAndRender(state).then(() => {
      setStatus(state, 'Folder deleted.');
    });
  }

  function handleFolderColor(state, folderId, buttonEl) {
    const folder = getFolderById(state, folderId);
    if (!folder) return;

    const current = folder.color || 'default';
    const currentIndex = window.CGV.constants.folderColors.indexOf(current);
    const nextIndex = currentIndex >= 0 ? (currentIndex + 1) % window.CGV.constants.folderColors.length : 0;
    const nextColor = window.CGV.constants.folderColors[nextIndex];

    window.CGV.core.setFolderColor(state.data, folderId, nextColor);

    if (buttonEl) {
      buttonEl.textContent = `Color: ${nextColor}`;
    }

    saveAndRender(state).then(() => {
      setStatus(state, `Folder color changed to ${nextColor}.`);
    });
  }

  function handleMappingExport(state, folderId) {
    const result = window.CGV.exporter.exportFolderMapping(state.data, folderId);
    if (!result.ok) {
      setStatus(state, result.error || 'Export failed.', true);
      return;
    }
    setStatus(state, `Exported ${result.count} mapped items.`);
  }

  async function handleContentExport(state, folderId, buttonEl) {
    if (buttonEl) {
      buttonEl.disabled = true;
      buttonEl.textContent = 'Exporting...';
    }

    try {
      const result = await window.CGV.exporter.exportFolderConversations(state.data, folderId);
      if (!result.ok) {
        setStatus(state, result.error || 'Content export failed.', true);
        return;
      }

      if (result.failedCount > 0) {
        setStatus(state, `Exported ${result.exportedCount}, failed ${result.failedCount}.`);
      } else {
        setStatus(state, `Exported ${result.exportedCount} conversations.`);
      }
    } finally {
      if (buttonEl) {
        buttonEl.disabled = false;
        buttonEl.textContent = 'Export Content';
      }
    }
  }

  function openConversation(conversationId) {
    const url = `${window.location.origin}/c/${conversationId}`;
    window.location.assign(url);
  }

  function handleFolderDragStart(event, folderId) {
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData(
      window.CGV.constants.dragTypeFolder,
      JSON.stringify({ folderId })
    );
  }

  function getDropPosition(event, targetEl) {
    const rect = targetEl.getBoundingClientRect();
    const midpoint = rect.top + rect.height / 2;
    return event.clientY >= midpoint ? 'after' : 'before';
  }

  function handleFolderDropReorder(state, event, targetFolderId, targetEl) {
    if (!event.dataTransfer) return false;
    const payloadRaw = event.dataTransfer.getData(window.CGV.constants.dragTypeFolder);
    if (!payloadRaw) return false;

    let payload;
    try {
      payload = JSON.parse(payloadRaw);
    } catch {
      return false;
    }

    const draggedFolderId = payload?.folderId;
    if (!draggedFolderId || draggedFolderId === targetFolderId) return false;

    const position = getDropPosition(event, targetEl);
    const placeAfter = position === 'after';

    const changed = window.CGV.core.reorderFolders(
      state.data,
      draggedFolderId,
      targetFolderId,
      placeAfter
    );

    if (!changed) return false;

    saveAndRender(state).then(() => {
      setStatus(state, 'Folder order updated.');
    });

    return true;
  }

  function handleConversationDragStart(event, payload) {
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData(window.CGV.constants.dragTypeConversation, JSON.stringify(payload));
  }

  function handleFolderConversationDragStart(event, payload) {
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData(window.CGV.constants.dragTypeFolderConversation, JSON.stringify(payload));
  }

  function parsePayload(dataTransfer, type) {
    const raw = dataTransfer.getData(type);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  function bindNativeConversationDrag(state) {
    const scanned = window.CGV.chatgptAdapter.scanConversations();

    scanned.forEach(({ anchor, conversation }) => {
      window.CGV.core.updateConversationMetadata(state.data, conversation);
      window.CGV.chatgptAdapter.makeNativeConversationDraggable(anchor, conversation, (event, conv) => {
        handleConversationDragStart(event, {
          conversationId: conv.conversationId,
          title: clampTitle(conv.title),
          url: conv.url
        });
      });
    });
  }

  function createFolderHeader(state, folder) {
    const folderColor = getFolderColorHex(folder.color || 'default');
    const conversationCount = conversationsForFolder(state, folder.id).length;

    const header = createElementFromHTML(`
      <div class="cgv-folder-header" draggable="true" data-folder-id="${escapeHtml(folder.id)}">
        <div class="cgv-folder-main">
          <span class="cgv-folder-dot" style="background:${escapeHtml(folderColor)}"></span>
          <span class="cgv-folder-name">${escapeHtml(folder.name)}</span>
          <span class="cgv-folder-count">(${conversationCount})</span>
        </div>
        <div class="cgv-folder-actions">
          <button type="button" class="cgv-btn" data-action="rename">Rename</button>
          <button type="button" class="cgv-btn" data-action="color">Color: ${escapeHtml(folder.color || 'default')}</button>
          <button type="button" class="cgv-btn" data-action="export-map">Export Map</button>
          <button type="button" class="cgv-btn" data-action="export-content">Export Content</button>
          <button type="button" class="cgv-btn cgv-btn-danger" data-action="delete">Delete</button>
        </div>
      </div>
    `);

    header.addEventListener('dragstart', (event) => {
      handleFolderDragStart(event, folder.id);
    });

    header.addEventListener('dragover', (event) => {
      event.preventDefault();
      header.classList.add('cgv-drop-active');
    });

    header.addEventListener('dragleave', () => {
      header.classList.remove('cgv-drop-active');
    });

    header.addEventListener('drop', (event) => {
      event.preventDefault();
      header.classList.remove('cgv-drop-active');

      const reordered = handleFolderDropReorder(state, event, folder.id, header);
      if (reordered) return;

      const nativePayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeConversation);
      if (nativePayload && nativePayload.conversationId) {
        const changed = window.CGV.core.assignConversationToFolder(state.data, folder.id, {
          conversationId: nativePayload.conversationId,
          title: clampTitle(nativePayload.title),
          url: nativePayload.url
        });

        if (changed) {
          saveAndRender(state).then(() => {
            setStatus(state, 'Conversation moved to folder.');
          });
        }
        return;
      }

      const folderConversationPayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeFolderConversation);
      if (folderConversationPayload && folderConversationPayload.conversationId) {
        const sourceFolderId = folderConversationPayload.sourceFolderId;
        const conversationId = folderConversationPayload.conversationId;

        if (
          sourceFolderId &&
          sourceFolderId !== folder.id &&
          getFolderConversationData(state, folder.id, conversationId) === null
        ) {
          const changed = window.CGV.core.moveConversationBetweenFolders(
            state.data,
            sourceFolderId,
            folder.id,
            conversationId
          );

          if (changed) {
            saveAndRender(state).then(() => {
              setStatus(state, 'Conversation moved between folders.');
            });
          }
        }
      }
    });

    const actionButtons = Array.from(header.querySelectorAll('button[data-action]'));
    actionButtons.forEach((button) => {
      button.addEventListener('click', () => {
        const action = button.dataset.action;
        if (action === 'rename') {
          state.deletePendingFolderId = null;
          if (state.editingFolderId === folder.id) {
            state.editingFolderId = null;
          } else {
            state.editingFolderId = folder.id;
          }
          setStatus(state, '');
          render(state);
          return;
        }
        if (action === 'color') {
          handleFolderColor(state, folder.id, button);
          return;
        }
        if (action === 'delete') {
          state.editingFolderId = null;
          if (state.deletePendingFolderId === folder.id) {
            state.deletePendingFolderId = null;
          } else {
            state.deletePendingFolderId = folder.id;
          }
          setStatus(state, '');
          render(state);
          return;
        }
        if (action === 'export-map') {
          handleMappingExport(state, folder.id);
          return;
        }
        if (action === 'export-content') {
          handleContentExport(state, folder.id, button);
        }
      });
    });

    return header;
  }

  function createFolderInlineEditor(state, folder) {
    const editor = createElementFromHTML(`
      <div class="cgv-inline-editor">
        <input type="text" class="cgv-input" data-role="rename-input" value="${escapeHtml(folder.name)}" maxlength="60" />
        <button type="button" class="cgv-btn cgv-btn-primary" data-action="rename-save">Save</button>
        <button type="button" class="cgv-btn" data-action="rename-cancel">Cancel</button>
      </div>
    `);

    const input = editor.querySelector('input[data-role="rename-input"]');
    const saveBtn = editor.querySelector('button[data-action="rename-save"]');
    const cancelBtn = editor.querySelector('button[data-action="rename-cancel"]');

    if (saveBtn && input) {
      saveBtn.addEventListener('click', () => {
        commitRenameFolder(state, folder.id, input.value);
      });
    }

    if (input) {
      input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          commitRenameFolder(state, folder.id, input.value);
        }
      });
    }

    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        state.editingFolderId = null;
        render(state);
      });
    }

    return editor;
  }

  function createFolderDeleteConfirmation(state, folder) {
    const confirmation = createElementFromHTML(`
      <div class="cgv-inline-editor cgv-inline-danger">
        <span class="cgv-confirm-text">Delete folder "${escapeHtml(folder.name)}"?</span>
        <button type="button" class="cgv-btn cgv-btn-danger" data-action="delete-confirm">Delete</button>
        <button type="button" class="cgv-btn" data-action="delete-cancel">Cancel</button>
      </div>
    `);

    const confirmBtn = confirmation.querySelector('button[data-action="delete-confirm"]');
    const cancelBtn = confirmation.querySelector('button[data-action="delete-cancel"]');

    if (confirmBtn) {
      confirmBtn.addEventListener('click', () => {
        commitDeleteFolder(state, folder.id);
      });
    }

    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        state.deletePendingFolderId = null;
        render(state);
      });
    }

    return confirmation;
  }

  function createConversationRow(state, folderId, conversation, index) {
    const row = createElementFromHTML(`
      <div class="cgv-conversation-row" draggable="true" data-conversation-id="${escapeHtml(conversation.conversationId)}">
        <span class="cgv-conversation-title">${escapeHtml(conversation.title)}</span>
        <div class="cgv-conversation-actions">
          <button type="button" class="cgv-btn" data-action="open">Open</button>
          <button type="button" class="cgv-btn cgv-btn-danger" data-action="remove">Remove</button>
        </div>
      </div>
    `);

    row.addEventListener('dragstart', (event) => {
      handleFolderConversationDragStart(event, {
        sourceFolderId: folderId,
        conversationId: conversation.conversationId,
        title: clampTitle(conversation.title),
        url: conversation.url
      });
    });

    row.addEventListener('dragover', (event) => {
      event.preventDefault();
      row.classList.add('cgv-drop-active');
    });

    row.addEventListener('dragleave', () => {
      row.classList.remove('cgv-drop-active');
    });

    row.addEventListener('drop', (event) => {
      event.preventDefault();
      row.classList.remove('cgv-drop-active');

      const payload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeFolderConversation);
      if (!payload || !payload.conversationId) return;

      if (payload.sourceFolderId !== folderId) {
        const moved = window.CGV.core.moveConversationBetweenFolders(
          state.data,
          payload.sourceFolderId,
          folderId,
          payload.conversationId,
          index
        );

        if (moved) {
          saveAndRender(state).then(() => {
            setStatus(state, 'Conversation moved and inserted.');
          });
        }
        return;
      }

      const position = getDropPosition(event, row);
      const placeAfter = position === 'after';

      const changed = window.CGV.core.reorderConversationWithinFolder(
        state.data,
        folderId,
        payload.conversationId,
        conversation.conversationId,
        placeAfter
      );

      if (changed) {
        saveAndRender(state).then(() => {
          setStatus(state, 'Conversation order updated.');
        });
      }
    });

    row.addEventListener('click', (event) => {
      if (event.target instanceof HTMLButtonElement) return;
      openConversation(conversation.conversationId);
    });

    const buttons = Array.from(row.querySelectorAll('button[data-action]'));
    buttons.forEach((button) => {
      button.addEventListener('click', () => {
        const action = button.dataset.action;
        if (action === 'open') {
          state.editingFolderId = null;
          state.deletePendingFolderId = null;
          setStatus(state, '');
          render(state);
          openConversation(conversation.conversationId);
          return;
        }
        if (action === 'remove') {
          const changed = window.CGV.core.removeConversationFromFolder(
            state.data,
            folderId,
            conversation.conversationId
          );
          if (changed) {
            saveAndRender(state).then(() => {
              setStatus(state, 'Conversation removed from folder.');
            });
          }
        }
      });
    });

    return row;
  }

  function createFolderCard(state, folder) {
    const card = createElementFromHTML('<section class="cgv-folder-card"></section>');

    const header = createFolderHeader(state, folder);
    card.appendChild(header);

    if (state.editingFolderId === folder.id) {
      card.appendChild(createFolderInlineEditor(state, folder));
    }

    if (state.deletePendingFolderId === folder.id) {
      card.appendChild(createFolderDeleteConfirmation(state, folder));
    }

    const list = createElementFromHTML('<div class="cgv-conversation-list"></div>');
    const conversations = conversationsForFolder(state, folder.id);

    if (conversations.length === 0) {
      const empty = createElementFromHTML('<div class="cgv-empty">Drop a conversation here</div>');
      list.appendChild(empty);
    } else {
      conversations.forEach((conversation, index) => {
        list.appendChild(createConversationRow(state, folder.id, conversation, index));
      });
    }

    list.addEventListener('dragover', (event) => {
      event.preventDefault();
      list.classList.add('cgv-drop-active');
    });

    list.addEventListener('dragleave', () => {
      list.classList.remove('cgv-drop-active');
    });

    list.addEventListener('drop', (event) => {
      event.preventDefault();
      list.classList.remove('cgv-drop-active');

      const nativePayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeConversation);
      if (nativePayload && nativePayload.conversationId) {
        const changed = window.CGV.core.assignConversationToFolder(state.data, folder.id, {
          conversationId: nativePayload.conversationId,
          title: clampTitle(nativePayload.title),
          url: nativePayload.url
        });

        if (changed) {
          saveAndRender(state).then(() => {
            setStatus(state, 'Conversation moved to folder.');
          });
        }
        return;
      }

      const folderPayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeFolderConversation);
      if (!folderPayload || !folderPayload.conversationId) return;

      if (folderPayload.sourceFolderId && folderPayload.sourceFolderId !== folder.id) {
        const moved = window.CGV.core.moveConversationBetweenFolders(
          state.data,
          folderPayload.sourceFolderId,
          folder.id,
          folderPayload.conversationId
        );

        if (moved) {
          saveAndRender(state).then(() => {
            setStatus(state, 'Conversation moved between folders.');
          });
        }
      }
    });

    card.appendChild(list);
    return card;
  }

  function createRoot(state) {
    const root = createElementFromHTML('<section class="cgv-root"></section>');

    const toolbar = createElementFromHTML(`
      <header class="cgv-toolbar">
        <div class="cgv-title">ChatGPT Voyager</div>
        <div class="cgv-toolbar-actions cgv-toolbar-create">
          <input type="text" class="cgv-input" data-role="new-folder-name" placeholder="Folder name" maxlength="60" />
          <select class="cgv-select" data-role="new-folder-color">
            ${window.CGV.constants.folderColors
              .map((colorId) => `<option value="${escapeHtml(colorId)}">${escapeHtml(colorId)}</option>`)
              .join('')}
          </select>
          <button type="button" class="cgv-btn cgv-btn-primary" data-action="new-folder">Create</button>
        </div>
      </header>
    `);

    const status = createElementFromHTML('<div class="cgv-status" aria-live="polite"></div>');

    const folderContainer = createElementFromHTML('<div class="cgv-folder-container"></div>');

    const folders = folderListSorted(state);
    if (folders.length === 0) {
      folderContainer.appendChild(
        createElementFromHTML('<div class="cgv-empty">No folders yet. Click New Folder.</div>')
      );
    } else {
      folders.forEach((folder) => {
        folderContainer.appendChild(createFolderCard(state, folder));
      });
    }

    const newFolderButton = toolbar.querySelector('button[data-action="new-folder"]');
    const newFolderInput = toolbar.querySelector('input[data-role="new-folder-name"]');
    const newFolderColorSelect = toolbar.querySelector('select[data-role="new-folder-color"]');

    if (newFolderButton) {
      newFolderButton.addEventListener('click', () => {
        state.editingFolderId = null;
        state.deletePendingFolderId = null;
        commitCreateFolder(state, newFolderInput, newFolderColorSelect);
      });
    }

    if (newFolderInput) {
      newFolderInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          state.editingFolderId = null;
          state.deletePendingFolderId = null;
          commitCreateFolder(state, newFolderInput, newFolderColorSelect);
        }
      });
    }

    root.append(toolbar, status, folderContainer);

    state.statusEl = status;

    return root;
  }

  function ensureMount() {
    const sidebar = window.CGV.chatgptAdapter.getSidebarContainer();
    if (!sidebar) return null;

    let mount = document.getElementById(window.CGV.constants.appRootId);
    if (!mount) {
      mount = document.createElement('div');
      mount.id = window.CGV.constants.appRootId;
      sidebar.prepend(mount);
    } else if (mount.parentElement !== sidebar) {
      sidebar.prepend(mount);
    }

    return mount;
  }

  function render(state) {
    const mount = ensureMount();
    if (!mount) return;

    bindNativeConversationDrag(state);

    mount.innerHTML = '';
    mount.appendChild(createRoot(state));
  }

  function init(state) {
    render(state);

    const stopObserve = window.CGV.chatgptAdapter.observeApp(() => {
      render(state);
    });

    return () => {
      if (typeof stopObserve === 'function') {
        stopObserve();
      }
    };
  }

  window.CGV.ui = {
    init,
    render
  };
})();
