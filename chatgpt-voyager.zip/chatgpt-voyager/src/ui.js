(() => {
  'use strict';

  window.CGV = window.CGV || {};

  function escapeHtml(input) {
    const text = String(input || '');
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function clampTitle(input) {
    const text = String(input || '').trim();
    if (!text) return '未命名会话';
    return text.slice(0, window.CGV.constants.maxTitleLength);
  }

  function clampFolderName(input) {
    const text = String(input || '').trim();
    if (!text) return null;
    return text.slice(0, 60);
  }

  function createElementFromHTML(html) {
    const template = document.createElement('template');
    template.innerHTML = html.trim();
    return template.content.firstElementChild;
  }

  function getFolderColorHex(colorId) {
    const map = window.CGV.constants.folderColorMap;
    return map[colorId] || map.default;
  }

  function getFolderById(state, folderId) {
    return window.CGV.core.getFolderById(state.data, folderId);
  }

  function ensureUiState(state) {
    if (!(state.collapsedFolderIds instanceof Set)) {
      state.collapsedFolderIds = new Set();
    }
    if (typeof state.showCreateRow !== 'boolean') {
      state.showCreateRow = false;
    }
    if (typeof state.openMenuFolderId !== 'string' && state.openMenuFolderId !== null) {
      state.openMenuFolderId = null;
    }
    if (typeof state.openColorPaletteFolderId !== 'string' && state.openColorPaletteFolderId !== null) {
      state.openColorPaletteFolderId = null;
    }
    if (typeof state.exportingContentFolderId !== 'string' && state.exportingContentFolderId !== null) {
      state.exportingContentFolderId = null;
    }
    if (typeof state.boundOutsideClick !== 'boolean') {
      state.boundOutsideClick = false;
    }
    if (typeof state.boundEscapeKey !== 'boolean') {
      state.boundEscapeKey = false;
    }
  }

  function closeTransientUi(state) {
    state.openMenuFolderId = null;
    state.openColorPaletteFolderId = null;
    state.deletePendingFolderId = null;
    state.editingFolderId = null;
  }

  function isFolderCollapsed(state, folderId) {
    ensureUiState(state);
    return state.collapsedFolderIds.has(folderId);
  }

  function toggleFolderCollapsed(state, folderId) {
    ensureUiState(state);
    if (state.collapsedFolderIds.has(folderId)) {
      state.collapsedFolderIds.delete(folderId);
    } else {
      state.collapsedFolderIds.add(folderId);
    }
  }

  function saveAndRender(state) {
    return window.CGV.storage.save(state.data).then(() => {
      render(state);
    });
  }

  function folderListSorted(state) {
    return window.CGV.core.sortFolders(state.data);
  }

  function conversationsForFolder(state, folderId) {
    return window.CGV.core.sortConversations(state.data, folderId);
  }

  function setStatus(state, message, isError) {
    if (!state.statusEl) return;
    state.statusEl.textContent = message || '';
    state.statusEl.classList.toggle('cgv-status-error', Boolean(isError));
    state.statusEl.classList.toggle('is-empty', !message);
  }

  function getFolderConversationData(state, folderId, conversationId) {
    const list = window.CGV.core.ensureFolderContents(state.data, folderId);
    return list.find((item) => item.conversationId === conversationId) || null;
  }

  function commitCreateFolder(state, inputEl, colorSelectEl) {
    const normalized = clampFolderName(inputEl?.value || '');
    if (!normalized) {
      setStatus(state, '文件夹名称不能为空', true);
      return;
    }

    const color =
      colorSelectEl && typeof colorSelectEl.value === 'string' && colorSelectEl.value
        ? colorSelectEl.value
        : 'default';

    closeTransientUi(state);
    window.CGV.core.createFolder(state.data, { name: normalized, color });

    if (inputEl) {
      inputEl.value = '';
    }
    if (colorSelectEl) {
      colorSelectEl.value = 'default';
    }

    state.showCreateRow = false;
    saveAndRender(state).then(() => {
      setStatus(state, '文件夹已创建');
    });
  }

  function commitRenameFolder(state, folderId, nextName) {
    const normalized = clampFolderName(nextName);
    if (!normalized) {
      setStatus(state, '文件夹名称不能为空', true);
      return;
    }

    const changed = window.CGV.core.renameFolder(state.data, folderId, normalized);
    if (!changed) {
      setStatus(state, '重命名失败', true);
      return;
    }

    closeTransientUi(state);
    saveAndRender(state).then(() => {
      setStatus(state, '文件夹已重命名');
    });
  }

  function commitDeleteFolder(state, folderId) {
    const folder = getFolderById(state, folderId);
    if (!folder) {
      setStatus(state, '未找到该文件夹', true);
      return;
    }

    const changed = window.CGV.core.deleteFolder(state.data, folderId);
    if (!changed) {
      setStatus(state, '删除失败', true);
      return;
    }

    closeTransientUi(state);

    saveAndRender(state).then(() => {
      setStatus(state, '文件夹已删除');
    });
  }

  function applyFolderColor(state, folderId, color) {
    if (!color) return;

    const changed = window.CGV.core.setFolderColor(state.data, folderId, color);
    if (!changed) return;

    state.openColorPaletteFolderId = null;
    saveAndRender(state).then(() => {
      setStatus(state, `文件夹颜色已改为 ${color}`);
    });
  }

  function toggleFolderPinned(state, folderId) {
    const folder = getFolderById(state, folderId);
    if (!folder) return;

    const nextPinned = !folder.pinned;
    const changed = window.CGV.core.setFolderPinned(state.data, folderId, nextPinned);
    if (!changed) return;

    state.openMenuFolderId = null;
    state.openColorPaletteFolderId = null;
    saveAndRender(state).then(() => {
      setStatus(state, nextPinned ? '文件夹已置顶' : '已取消置顶');
    });
  }

  function handleMappingExport(state, folderId) {
    const result = window.CGV.exporter.exportFolderMapping(state.data, folderId);
    if (!result.ok) {
      setStatus(state, result.error || '导出失败', true);
      return;
    }
    setStatus(state, `已导出 ${result.count} 条映射`);
  }

  async function handleContentExport(state, folderId) {
    ensureUiState(state);
    state.exportingContentFolderId = folderId;
    render(state);

    try {
      const result = await window.CGV.exporter.exportFolderConversations(state.data, folderId);
      if (!result.ok) {
        setStatus(state, result.error || '内容导出失败', true);
        return;
      }

      if (result.failedCount > 0) {
        setStatus(state, `已导出 ${result.exportedCount} 条，失败 ${result.failedCount} 条`);
      } else {
        setStatus(state, `已导出 ${result.exportedCount} 条会话`);
      }
    } finally {
      state.exportingContentFolderId = null;
      render(state);
    }
  }

  function openConversation(conversationId) {
    const url = `${window.location.origin}/c/${conversationId}`;
    window.location.assign(url);
  }

  function handleFolderDragStart(event, folderId) {
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData(
      window.CGV.constants.dragTypeFolder,
      JSON.stringify({ folderId })
    );
  }

  function getDropPosition(event, targetEl) {
    const rect = targetEl.getBoundingClientRect();
    const midpoint = rect.top + rect.height / 2;
    return event.clientY >= midpoint ? 'after' : 'before';
  }

  function handleFolderDropReorder(state, event, targetFolderId, targetEl) {
    if (!event.dataTransfer) return false;
    const payloadRaw = event.dataTransfer.getData(window.CGV.constants.dragTypeFolder);
    if (!payloadRaw) return false;

    let payload;
    try {
      payload = JSON.parse(payloadRaw);
    } catch {
      return false;
    }

    const draggedFolderId = payload?.folderId;
    if (!draggedFolderId || draggedFolderId === targetFolderId) return false;

    const position = getDropPosition(event, targetEl);
    const placeAfter = position === 'after';

    const changed = window.CGV.core.reorderFolders(
      state.data,
      draggedFolderId,
      targetFolderId,
      placeAfter
    );

    if (!changed) return false;

    saveAndRender(state).then(() => {
      setStatus(state, '文件夹顺序已更新');
    });

    return true;
  }

  function handleConversationDragStart(event, payload) {
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData(window.CGV.constants.dragTypeConversation, JSON.stringify(payload));
  }

  function handleFolderConversationDragStart(event, payload) {
    if (!event.dataTransfer) return;
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData(window.CGV.constants.dragTypeFolderConversation, JSON.stringify(payload));
  }

  function parsePayload(dataTransfer, type) {
    const raw = dataTransfer.getData(type);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  function bindNativeConversationDrag(state) {
    const scanned = window.CGV.chatgptAdapter.scanConversations();

    scanned.forEach(({ anchor, conversation }) => {
      window.CGV.core.updateConversationMetadata(state.data, conversation);
      window.CGV.chatgptAdapter.makeNativeConversationDraggable(anchor, conversation, (event, conv) => {
        handleConversationDragStart(event, {
          conversationId: conv.conversationId,
          title: clampTitle(conv.title),
          url: conv.url
        });
      });
    });
  }

  function createFolderHeader(state, folder) {
    ensureUiState(state);
    const folderColor = getFolderColorHex(folder.color || 'default');
    const conversationCount = conversationsForFolder(state, folder.id).length;
    const collapsed = isFolderCollapsed(state, folder.id);
    const menuOpen = state.openMenuFolderId === folder.id;

    const header = createElementFromHTML(`
      <div class="cgv-folder-header" draggable="true" data-folder-id="${escapeHtml(folder.id)}">
        <button type="button" class="cgv-icon-btn cgv-folder-toggle" data-action="toggle-folder" aria-label="展开/收起文件夹">
          ${collapsed ? '▸' : '▾'}
        </button>
        <button type="button" class="cgv-folder-main" data-action="toggle-folder" title="${escapeHtml(folder.name)}">
          <span class="cgv-folder-icon" style="--cgv-folder-color:${escapeHtml(folderColor)}" aria-hidden="true"></span>
          <span class="cgv-folder-name">${escapeHtml(folder.name)}</span>
          <span class="cgv-folder-count">${conversationCount}</span>
          ${folder.pinned ? '<span class="cgv-folder-pin" aria-label="已置顶">📌</span>' : ''}
        </button>
        <button type="button" class="cgv-icon-btn cgv-folder-menu-btn ${menuOpen ? 'is-active' : ''}" data-action="toggle-menu" aria-label="文件夹菜单">⋮</button>
      </div>
    `);

    header.addEventListener('dragstart', (event) => {
      handleFolderDragStart(event, folder.id);
    });

    header.addEventListener('dragover', (event) => {
      event.preventDefault();
      header.classList.add('cgv-drop-active');
    });

    header.addEventListener('dragleave', () => {
      header.classList.remove('cgv-drop-active');
    });

    header.addEventListener('drop', (event) => {
      event.preventDefault();
      header.classList.remove('cgv-drop-active');

      const reordered = handleFolderDropReorder(state, event, folder.id, header);
      if (reordered) return;

      const nativePayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeConversation);
      if (nativePayload && nativePayload.conversationId) {
        const changed = window.CGV.core.assignConversationToFolder(state.data, folder.id, {
          conversationId: nativePayload.conversationId,
          title: clampTitle(nativePayload.title),
          url: nativePayload.url
        });

        if (changed) {
          saveAndRender(state).then(() => {
            setStatus(state, '会话已移动到文件夹');
          });
        }
        return;
      }

      const folderConversationPayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeFolderConversation);
      if (folderConversationPayload && folderConversationPayload.conversationId) {
        const sourceFolderId = folderConversationPayload.sourceFolderId;
        const conversationId = folderConversationPayload.conversationId;

        if (
          sourceFolderId &&
          sourceFolderId !== folder.id &&
          getFolderConversationData(state, folder.id, conversationId) === null
        ) {
          const changed = window.CGV.core.moveConversationBetweenFolders(
            state.data,
            sourceFolderId,
            folder.id,
            conversationId
          );

          if (changed) {
            saveAndRender(state).then(() => {
              setStatus(state, '会话已移动到其他文件夹');
            });
          }
        }
      }
    });

    const toggleButtons = Array.from(header.querySelectorAll('button[data-action="toggle-folder"]'));
    toggleButtons.forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        toggleFolderCollapsed(state, folder.id);
        render(state);
      });
    });

    const menuButton = header.querySelector('button[data-action="toggle-menu"]');
    if (menuButton) {
      menuButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();

        if (state.openMenuFolderId === folder.id) {
          state.openMenuFolderId = null;
          state.openColorPaletteFolderId = null;
        } else {
          state.openMenuFolderId = folder.id;
          state.openColorPaletteFolderId = null;
          state.editingFolderId = null;
          state.deletePendingFolderId = null;
        }

        setStatus(state, '');
        render(state);
      });
    }

    return header;
  }

  function createFolderMenu(state, folder) {
    const exportingContent = state.exportingContentFolderId === folder.id;

    const menu = createElementFromHTML(`
      <div class="cgv-folder-menu" role="menu">
        <button type="button" class="cgv-menu-item" data-action="pin">${folder.pinned ? '取消置顶' : '置顶文件夹'}</button>
        <button type="button" class="cgv-menu-item" data-action="rename">重命名</button>
        <button type="button" class="cgv-menu-item" data-action="color">更改颜色</button>
        <button type="button" class="cgv-menu-item" data-action="export-map">导出映射</button>
        <button type="button" class="cgv-menu-item" data-action="export-content" ${exportingContent ? 'disabled' : ''}>
          ${exportingContent ? '导出中...' : '导出内容'}
        </button>
        <button type="button" class="cgv-menu-item cgv-menu-item-danger" data-action="delete">删除</button>
      </div>
    `);

    const buttons = Array.from(menu.querySelectorAll('button[data-action]'));
    buttons.forEach((button) => {
      button.addEventListener('click', () => {
        const action = button.dataset.action;
        if (action === 'pin') {
          toggleFolderPinned(state, folder.id);
          return;
        }

        if (action === 'rename') {
          state.openMenuFolderId = null;
          state.openColorPaletteFolderId = null;
          state.deletePendingFolderId = null;
          state.editingFolderId = folder.id;
          render(state);
          return;
        }

        if (action === 'color') {
          state.openMenuFolderId = null;
          if (state.openColorPaletteFolderId === folder.id) {
            state.openColorPaletteFolderId = null;
          } else {
            state.openColorPaletteFolderId = folder.id;
            state.editingFolderId = null;
            state.deletePendingFolderId = null;
          }
          render(state);
          return;
        }

        if (action === 'delete') {
          state.openMenuFolderId = null;
          state.openColorPaletteFolderId = null;
          state.editingFolderId = null;
          state.deletePendingFolderId = folder.id;
          render(state);
          return;
        }

        if (action === 'export-map') {
          state.openMenuFolderId = null;
          state.openColorPaletteFolderId = null;
          render(state);
          handleMappingExport(state, folder.id);
          return;
        }

        if (action === 'export-content') {
          state.openMenuFolderId = null;
          state.openColorPaletteFolderId = null;
          render(state);
          handleContentExport(state, folder.id);
        }
      });
    });

    return menu;
  }

  function createFolderColorPalette(state, folder) {
    const currentColor = folder.color || 'default';
    const palette = createElementFromHTML('<div class="cgv-color-palette"></div>');

    window.CGV.constants.folderColors.forEach((colorId) => {
      const colorHex = getFolderColorHex(colorId);
      const option = createElementFromHTML(`
        <button
          type="button"
          class="cgv-color-option ${colorId === currentColor ? 'is-active' : ''}"
          data-color="${escapeHtml(colorId)}"
          aria-label="设置颜色 ${escapeHtml(colorId)}"
          title="${escapeHtml(colorId)}"
          style="--cgv-color:${escapeHtml(colorHex)}"
        ></button>
      `);

      option.addEventListener('click', () => {
        applyFolderColor(state, folder.id, colorId);
      });

      palette.appendChild(option);
    });

    return palette;
  }

  function createFolderInlineEditor(state, folder) {
    const editor = createElementFromHTML(`
      <div class="cgv-inline-editor">
        <input type="text" class="cgv-input" data-role="rename-input" value="${escapeHtml(folder.name)}" maxlength="60" />
        <button type="button" class="cgv-btn cgv-btn-primary" data-action="rename-save">保存</button>
        <button type="button" class="cgv-btn" data-action="rename-cancel">取消</button>
      </div>
    `);

    const input = editor.querySelector('input[data-role="rename-input"]');
    const saveBtn = editor.querySelector('button[data-action="rename-save"]');
    const cancelBtn = editor.querySelector('button[data-action="rename-cancel"]');

    if (saveBtn && input) {
      saveBtn.addEventListener('click', () => {
        commitRenameFolder(state, folder.id, input.value);
      });
    }

    if (input) {
      input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          commitRenameFolder(state, folder.id, input.value);
        }
      });
    }

    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        state.editingFolderId = null;
        setStatus(state, '');
        render(state);
      });
    }

    return editor;
  }

  function createFolderDeleteConfirmation(state, folder) {
    const confirmation = createElementFromHTML(`
      <div class="cgv-inline-editor cgv-inline-danger">
        <span class="cgv-confirm-text">删除文件夹 “${escapeHtml(folder.name)}”？</span>
        <button type="button" class="cgv-btn cgv-btn-danger" data-action="delete-confirm">删除</button>
        <button type="button" class="cgv-btn" data-action="delete-cancel">取消</button>
      </div>
    `);

    const confirmBtn = confirmation.querySelector('button[data-action="delete-confirm"]');
    const cancelBtn = confirmation.querySelector('button[data-action="delete-cancel"]');

    if (confirmBtn) {
      confirmBtn.addEventListener('click', () => {
        commitDeleteFolder(state, folder.id);
      });
    }

    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        state.deletePendingFolderId = null;
        setStatus(state, '');
        render(state);
      });
    }

    return confirmation;
  }

  function createConversationRow(state, folderId, conversation, index) {
    const row = createElementFromHTML(`
      <div class="cgv-conversation-row" draggable="true" data-conversation-id="${escapeHtml(conversation.conversationId)}">
        <button type="button" class="cgv-conversation-open" data-action="open" title="${escapeHtml(conversation.title)}">
          <span class="cgv-conversation-title">${escapeHtml(conversation.title)}</span>
        </button>
        <button type="button" class="cgv-icon-btn cgv-conversation-remove" data-action="remove" aria-label="从文件夹移除" title="移除">×</button>
      </div>
    `);

    row.addEventListener('dragstart', (event) => {
      handleFolderConversationDragStart(event, {
        sourceFolderId: folderId,
        conversationId: conversation.conversationId,
        title: clampTitle(conversation.title),
        url: conversation.url
      });
    });

    row.addEventListener('dragover', (event) => {
      event.preventDefault();
      row.classList.add('cgv-drop-active');
    });

    row.addEventListener('dragleave', () => {
      row.classList.remove('cgv-drop-active');
    });

    row.addEventListener('drop', (event) => {
      event.preventDefault();
      row.classList.remove('cgv-drop-active');

      const payload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeFolderConversation);
      if (!payload || !payload.conversationId) return;

      if (payload.sourceFolderId !== folderId) {
        const moved = window.CGV.core.moveConversationBetweenFolders(
          state.data,
          payload.sourceFolderId,
          folderId,
          payload.conversationId,
          index
        );

        if (moved) {
          saveAndRender(state).then(() => {
            setStatus(state, '会话已移动并插入');
          });
        }
        return;
      }

      const position = getDropPosition(event, row);
      const placeAfter = position === 'after';

      const changed = window.CGV.core.reorderConversationWithinFolder(
        state.data,
        folderId,
        payload.conversationId,
        conversation.conversationId,
        placeAfter
      );

      if (changed) {
        saveAndRender(state).then(() => {
          setStatus(state, '会话顺序已更新');
        });
      }
    });

    const buttons = Array.from(row.querySelectorAll('button[data-action]'));
    buttons.forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();

        const action = button.dataset.action;
        if (action === 'open') {
          closeTransientUi(state);
          state.showCreateRow = false;
          setStatus(state, '');
          render(state);
          openConversation(conversation.conversationId);
          return;
        }
        if (action === 'remove') {
          const changed = window.CGV.core.removeConversationFromFolder(
            state.data,
            folderId,
            conversation.conversationId
          );
          if (changed) {
            saveAndRender(state).then(() => {
              setStatus(state, '会话已从文件夹移除');
            });
          }
        }
      });
    });

    return row;
  }

  function createFolderCard(state, folder) {
    ensureUiState(state);
    const card = createElementFromHTML('<section class="cgv-folder-card"></section>');

    const header = createFolderHeader(state, folder);
    card.appendChild(header);

    if (state.openMenuFolderId === folder.id) {
      card.appendChild(createFolderMenu(state, folder));
    }

    if (state.openColorPaletteFolderId === folder.id) {
      card.appendChild(createFolderColorPalette(state, folder));
    }

    if (state.editingFolderId === folder.id) {
      card.appendChild(createFolderInlineEditor(state, folder));
    }

    if (state.deletePendingFolderId === folder.id) {
      card.appendChild(createFolderDeleteConfirmation(state, folder));
    }

    const collapsed = isFolderCollapsed(state, folder.id);
    const list = createElementFromHTML(`<div class="cgv-conversation-list ${collapsed ? 'is-collapsed' : ''}"></div>`);

    if (!collapsed) {
      const conversations = conversationsForFolder(state, folder.id);

      if (conversations.length === 0) {
        const empty = createElementFromHTML('<div class="cgv-empty">把会话拖到这里</div>');
        list.appendChild(empty);
      } else {
        conversations.forEach((conversation, index) => {
          list.appendChild(createConversationRow(state, folder.id, conversation, index));
        });
      }
    }

    list.addEventListener('dragover', (event) => {
      event.preventDefault();
      list.classList.add('cgv-drop-active');
    });

    list.addEventListener('dragleave', () => {
      list.classList.remove('cgv-drop-active');
    });

    list.addEventListener('drop', (event) => {
      event.preventDefault();
      list.classList.remove('cgv-drop-active');

      const nativePayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeConversation);
      if (nativePayload && nativePayload.conversationId) {
        const changed = window.CGV.core.assignConversationToFolder(state.data, folder.id, {
          conversationId: nativePayload.conversationId,
          title: clampTitle(nativePayload.title),
          url: nativePayload.url
        });

        if (changed) {
          saveAndRender(state).then(() => {
            setStatus(state, '会话已移动到文件夹');
          });
        }
        return;
      }

      const folderPayload = parsePayload(event.dataTransfer, window.CGV.constants.dragTypeFolderConversation);
      if (!folderPayload || !folderPayload.conversationId) return;

      if (folderPayload.sourceFolderId && folderPayload.sourceFolderId !== folder.id) {
        const moved = window.CGV.core.moveConversationBetweenFolders(
          state.data,
          folderPayload.sourceFolderId,
          folder.id,
          folderPayload.conversationId
        );

        if (moved) {
          saveAndRender(state).then(() => {
            setStatus(state, '会话已移动到其他文件夹');
          });
        }
      }
    });

    card.appendChild(list);
    return card;
  }

  function createRoot(state) {
    ensureUiState(state);
    const root = createElementFromHTML('<section class="cgv-root"></section>');

    const toolbar = createElementFromHTML(`
      <header class="cgv-toolbar">
        <div class="cgv-title">文件夹</div>
        <button type="button" class="cgv-icon-btn cgv-toolbar-add" data-action="toggle-create" aria-label="创建文件夹" title="创建文件夹">＋</button>
      </header>
    `);

    const status = createElementFromHTML('<div class="cgv-status" aria-live="polite"></div>');

    const createRow = createElementFromHTML(`
      <div class="cgv-create-row ${state.showCreateRow ? '' : 'is-hidden'}">
        <input type="text" class="cgv-input" data-role="new-folder-name" placeholder="新建文件夹" maxlength="60" />
        <select class="cgv-select" data-role="new-folder-color">
          ${window.CGV.constants.folderColors
            .map((colorId) => `<option value="${escapeHtml(colorId)}">${escapeHtml(colorId)}</option>`)
            .join('')}
        </select>
        <button type="button" class="cgv-btn cgv-btn-primary" data-action="new-folder">创建</button>
      </div>
    `);

    const folderContainer = createElementFromHTML('<div class="cgv-folder-container"></div>');

    const folders = folderListSorted(state);
    if (folders.length === 0) {
      folderContainer.appendChild(
        createElementFromHTML('<div class="cgv-empty">还没有文件夹，点击 + 创建。</div>')
      );
    } else {
      folders.forEach((folder) => {
        folderContainer.appendChild(createFolderCard(state, folder));
      });
    }

    const addButton = toolbar.querySelector('button[data-action="toggle-create"]');
    if (addButton) {
      addButton.addEventListener('click', () => {
        state.showCreateRow = !state.showCreateRow;
        if (state.showCreateRow) {
          closeTransientUi(state);
          setStatus(state, '');
        }
        render(state);
      });
    }

    const newFolderButton = createRow.querySelector('button[data-action="new-folder"]');
    const newFolderInput = createRow.querySelector('input[data-role="new-folder-name"]');
    const newFolderColorSelect = createRow.querySelector('select[data-role="new-folder-color"]');

    if (newFolderButton) {
      newFolderButton.addEventListener('click', () => {
        commitCreateFolder(state, newFolderInput, newFolderColorSelect);
      });
    }

    if (newFolderInput) {
      newFolderInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
          event.preventDefault();
          commitCreateFolder(state, newFolderInput, newFolderColorSelect);
        }
      });
    }

    root.append(toolbar, createRow, status, folderContainer);

    state.statusEl = status;

    return root;
  }

  function ensureMount() {
    const sidebar = window.CGV.chatgptAdapter.getSidebarContainer();
    if (!sidebar) return null;

    let mount = document.getElementById(window.CGV.constants.appRootId);
    if (!mount) {
      mount = document.createElement('div');
      mount.id = window.CGV.constants.appRootId;
      sidebar.prepend(mount);
    } else if (mount.parentElement !== sidebar) {
      sidebar.prepend(mount);
    }

    return mount;
  }

  function bindOutsideClick(state, mount) {
    if (!mount) return;
    if (state.boundOutsideClick === true) return;

    document.addEventListener('click', (event) => {
      if (!(event.target instanceof Node)) return;
      if (!mount.contains(event.target)) {
        ensureUiState(state);

        const hasTransientUi =
          state.openMenuFolderId !== null ||
          state.openColorPaletteFolderId !== null ||
          state.editingFolderId !== null ||
          state.deletePendingFolderId !== null ||
          state.showCreateRow === true;

        if (hasTransientUi) {
          closeTransientUi(state);
          state.showCreateRow = false;
          setStatus(state, '');
          render(state);
        }
      }
    });

    state.boundOutsideClick = true;
  }

  function bindEscapeKey(state) {
    if (state.boundEscapeKey === true) return;

    document.addEventListener('keydown', (event) => {
      if (event.key !== 'Escape') return;

      ensureUiState(state);
      const hasTransientUi =
        state.openMenuFolderId !== null ||
        state.openColorPaletteFolderId !== null ||
        state.editingFolderId !== null ||
        state.deletePendingFolderId !== null ||
        state.showCreateRow === true;

      if (hasTransientUi) {
        closeTransientUi(state);
        state.showCreateRow = false;
        setStatus(state, '');
        render(state);
      }
    });

    state.boundEscapeKey = true;
  }

  function render(state) {
    ensureUiState(state);
    const mount = ensureMount();
    if (!mount) return;

    bindOutsideClick(state, mount);
    bindEscapeKey(state);
    bindNativeConversationDrag(state);

    mount.innerHTML = '';
    mount.appendChild(createRoot(state));
  }

  function init(state) {
    render(state);

    const stopObserve = window.CGV.chatgptAdapter.observeApp(() => {
      render(state);
    });

    return () => {
      if (typeof stopObserve === 'function') {
        stopObserve();
      }
    };
  }

  window.CGV.ui = {
    init,
    render
  };
})();
