(() => {
  'use strict';

  window.CGV = window.CGV || {};

  function nowIso() {
    return new Date().toISOString();
  }

  function downloadFile(filename, content, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function sanitizeFilename(input) {
    return String(input || 'folder')
      .trim()
      .replace(/[\\/:*?"<>|]+/g, '-')
      .replace(/\s+/g, '_')
      .slice(0, 80);
  }

  function createMarkdownFileName(index, conversationId, title) {
    const suffix = sanitizeFilename(conversationId).slice(0, 24);
    const titlePart = sanitizeFilename(title || 'conversation').slice(0, 70);
    const ordered = String(index + 1).padStart(3, '0');
    return `${ordered}_${titlePart}_${suffix}.md`;
  }

  function createFolderPathName(folderName) {
    const safe = sanitizeFilename(folderName || 'folder').slice(0, 60);
    return safe || 'folder';
  }

  function createContentExportReadme(folder, exportedAt, exportedCount, failedCount) {
    const lines = [
      '# ChatGPT Voyager Folder Content Export',
      '',
      `- Folder: ${folder.name}`,
      `- Folder ID: ${folder.id}`,
      `- Exported At: ${exportedAt}`,
      '',
      '## Included files',
      '- `manifest.json`: export metadata and markdown file index.',
      '- `*.md`: one markdown file per successfully exported conversation.',
      '- `failures.json`: only present if some conversations failed to export.',
      '',
      '## Notes',
      `- Successful exports: ${exportedCount}`,
      `- Failed exports: ${failedCount}`,
      '- Use "Export Map" for folder-to-conversation mapping JSON.',
      '- This ZIP is intended for reading/archive of conversation content.',
      ''
    ];

    return lines.join('\n');
  }

  function exportFolderMapping(data, folderId) {
    const folder = window.CGV.core.getFolderById(data, folderId);
    if (!folder) {
      return { ok: false, error: 'Folder not found' };
    }

    const conversations = window.CGV.core.sortConversations(data, folderId);

    const payload = {
      format: 'chatgpt-voyager.folder-export.v1',
      exportedAt: nowIso(),
      mode: 'mapping',
      folder: {
        id: folder.id,
        name: folder.name,
        color: folder.color,
        sortIndex: folder.sortIndex
      },
      conversations: conversations.map((item) => ({
        conversationId: item.conversationId,
        title: item.title,
        url: item.url,
        sortIndex: item.sortIndex,
        addedAt: item.addedAt,
        updatedAt: item.updatedAt
      }))
    };

    const filename = `${sanitizeFilename(folder.name)}_mapping_${Date.now()}.json`;
    downloadFile(filename, JSON.stringify(payload, null, 2), 'application/json');
    return { ok: true, count: conversations.length };
  }

  function normalizeMessageText(text) {
    if (typeof text !== 'string') return '';
    return text
      .replace(/\r\n/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function extractMessagesFromCurrentDom() {
    const selectors = [
      '[data-message-author-role="user"]',
      '[data-message-author-role="assistant"]'
    ];

    const nodes = Array.from(document.querySelectorAll(selectors.join(',')));

    return nodes
      .map((node) => {
        const role = node.getAttribute('data-message-author-role') || 'unknown';
        const text = normalizeMessageText(node.textContent || '');
        if (!text) return null;
        return { role, text };
      })
      .filter((entry) => entry !== null);
  }

  async function waitForMessages(ms) {
    const start = Date.now();
    while (Date.now() - start < ms) {
      const msgs = extractMessagesFromCurrentDom();
      if (msgs.length > 0) return msgs;
      await new Promise((resolve) => setTimeout(resolve, 120));
    }
    return extractMessagesFromCurrentDom();
  }

  function renderMarkdownConversation(conversationTitle, messages, sourceUrl) {
    const lines = [];
    lines.push(`# ${conversationTitle || 'Untitled Conversation'}`);
    lines.push('');
    lines.push(`- Source: ${sourceUrl}`);
    lines.push(`- Exported: ${nowIso()}`);
    lines.push('');

    messages.forEach((msg) => {
      const role = msg.role === 'assistant' ? 'Assistant' : msg.role === 'user' ? 'User' : 'Unknown';
      lines.push(`## ${role}`);
      lines.push('');
      lines.push(msg.text);
      lines.push('');
    });

    return lines.join('\n');
  }

  function openConversationInBackground(url) {
    return new Promise((resolve) => {
      if (!chrome?.runtime?.sendMessage) {
        resolve({ ok: false, error: 'runtime messaging unavailable' });
        return;
      }

      chrome.runtime.sendMessage(
        {
          type: 'CGV_EXPORT_OPEN_TAB',
          url
        },
        (response) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: chrome.runtime.lastError.message || 'runtime error' });
            return;
          }
          resolve(response || { ok: false, error: 'no response' });
        }
      );
    });
  }

  async function exportFolderConversations(data, folderId) {
    const folder = window.CGV.core.getFolderById(data, folderId);
    if (!folder) {
      return { ok: false, error: 'Folder not found' };
    }

    const conversations = window.CGV.core.sortConversations(data, folderId);
    const failures = [];
    const exports = [];

    const activeId = window.CGV.chatgptAdapter.getActiveConversationId();

    for (const item of conversations) {
      try {
        const itemUrl = item.url || `${window.location.origin}/c/${item.conversationId}`;
        let messages = [];

        if (activeId && activeId === item.conversationId) {
          messages = await waitForMessages(1000);
        } else {
          const opened = await openConversationInBackground(itemUrl);
          if (!opened || !opened.ok) {
            failures.push({ conversationId: item.conversationId, title: item.title, reason: opened?.error || 'open failed' });
            continue;
          }

          const content = opened.content;
          if (!Array.isArray(content) || content.length === 0) {
            failures.push({ conversationId: item.conversationId, title: item.title, reason: 'empty content' });
            continue;
          }

          messages = content
            .map((entry) => {
              if (!entry || typeof entry !== 'object') return null;
              const role = entry.role === 'assistant' ? 'assistant' : entry.role === 'user' ? 'user' : 'unknown';
              const text = normalizeMessageText(String(entry.text || ''));
              if (!text) return null;
              return { role, text };
            })
            .filter((entry) => entry !== null);
        }

        if (messages.length === 0) {
          failures.push({ conversationId: item.conversationId, title: item.title, reason: 'no messages found' });
          continue;
        }

        const markdown = renderMarkdownConversation(item.title, messages, itemUrl);

        exports.push({
          conversationId: item.conversationId,
          title: item.title,
          url: itemUrl,
          markdown,
          messageCount: messages.length
        });
      } catch (error) {
        failures.push({
          conversationId: item.conversationId,
          title: item.title,
          reason: error instanceof Error ? error.message : 'unknown error'
        });
      }
    }

    const folderPath = createFolderPathName(folder.name);

    const exportedAt = nowIso();
    const manifestPayload = {
      format: 'chatgpt-voyager.folder-export.v2',
      exportedAt,
      mode: 'content-zip',
      folder: {
        id: folder.id,
        name: folder.name,
        color: folder.color,
        sortIndex: folder.sortIndex
      },
      exported: exports.map((item, index) => ({
        index,
        conversationId: item.conversationId,
        title: item.title,
        url: item.url,
        messageCount: item.messageCount,
        file: `${folderPath}/${createMarkdownFileName(index, item.conversationId, item.title)}`
      })),
      failures
    };

    const zipEntries = [
      {
        name: `${folderPath}/README.md`,
        content: createContentExportReadme(folder, exportedAt, exports.length, failures.length),
      },
      {
        name: `${folderPath}/manifest.json`,
        content: JSON.stringify(manifestPayload, null, 2),
      }
    ];

    exports.forEach((item, index) => {
      zipEntries.push({
        name: `${folderPath}/${createMarkdownFileName(index, item.conversationId, item.title)}`,
        content: item.markdown,
      });
    });

    if (failures.length > 0) {
      zipEntries.push({
        name: `${folderPath}/failures.json`,
        content: JSON.stringify(failures, null, 2),
      });
    }

    const filename = `${sanitizeFilename(folder.name)}_content_${Date.now()}.zip`;
    if (!window.CGV.zip || typeof window.CGV.zip.downloadZip !== 'function') {
      return { ok: false, error: 'zip module unavailable' };
    }

    window.CGV.zip.downloadZip(zipEntries, filename);

    return {
      ok: true,
      exportedCount: exports.length,
      failedCount: failures.length,
      failures,
      filename,
    };
  }

  window.CGV.exporter = {
    exportFolderMapping,
    exportFolderConversations
  };
})();
