(() => {
  'use strict';

  window.CGV = window.CGV || {};

  const SIDEBAR_CANDIDATE_SELECTORS = [
    'aside nav a[href*="/c/"]',
    'nav[aria-label] a[href*="/c/"]',
    'aside a[href*="/c/"]',
    'nav a[href*="/c/"]',
    '[data-testid*="history"] a[href*="/c/"]',
    '[data-testid*="conversation"] a[href*="/c/"]',
    '[data-testid*="sidebar"] a[href*="/c/"]',
    '[role="navigation"] a[href*="/c/"]',
    '[role="complementary"] a[href*="/c/"]'
  ];

  const TITLE_SELECTORS = [
    '[data-testid*="conversation-title"]',
    '[data-testid*="history-item"]',
    '[data-testid*="conversation"]',
    '[aria-label]',
    'span',
    'div'
  ];

  const CONTAINER_CANDIDATE_SELECTORS = [
    'aside nav',
    'aside',
    'nav[aria-label]',
    'nav',
    '[data-testid*="history"]',
    '[data-testid*="sidebar"]',
    '[role="navigation"]',
    '[role="complementary"]'
  ];

  const RECENTS_LABELS = ['recents', 'recent', '最近', '最近的', '近期', '最近会话'];

  function extractConversationIdFromUrl(url) {
    if (typeof url !== 'string' || !url) return null;
    const match = url.match(window.CGV.constants.conversationUrlPattern);
    return match ? match[1] : null;
  }

  function hasConversationHint(text) {
    const normalized = String(text || '').toLowerCase();
    return normalized.includes('history') || normalized.includes('chat') || normalized.includes('conversation');
  }

  function normalizeHref(href) {
    if (typeof href !== 'string') return '';
    return href.trim();
  }

  function isConversationAnchor(anchor) {
    if (!(anchor instanceof HTMLAnchorElement)) return false;
    const href = normalizeHref(anchor.getAttribute('href') || '');
    if (!href.includes('/c/')) return false;
    if (anchor.closest(`#${window.CGV.constants.appRootId}`)) return false;
    return extractConversationIdFromUrl(href) !== null;
  }

  function gatherCandidateAnchors() {
    const all = [];

    SIDEBAR_CANDIDATE_SELECTORS.forEach((selector) => {
      const nodes = Array.from(document.querySelectorAll(selector));
      nodes.forEach((node) => {
        if (node instanceof HTMLAnchorElement) {
          all.push(node);
        }
      });
    });

    if (all.length === 0) {
      const fallback = Array.from(document.querySelectorAll('a[href*="/c/"]'));
      fallback.forEach((node) => {
        if (node instanceof HTMLAnchorElement) {
          all.push(node);
        }
      });
    }

    const unique = [];
    const seen = new Set();
    all.forEach((anchor) => {
      if (seen.has(anchor)) return;
      seen.add(anchor);
      unique.push(anchor);
    });

    return unique.filter((anchor) => isConversationAnchor(anchor));
  }

  function getConversationTitleFromAnchor(anchor) {
    const ownText = (anchor.textContent || '').trim();
    if (ownText) return ownText;

    for (const selector of TITLE_SELECTORS) {
      const node = anchor.querySelector(selector);
      const text = (node?.textContent || '').trim();
      if (text) return text;
      const aria = (node?.getAttribute?.('aria-label') || '').trim();
      if (aria) return aria;
    }

    const aria = (anchor.getAttribute('aria-label') || '').trim();
    if (aria) return aria;

    const title = (anchor.getAttribute('title') || '').trim();
    if (title) return title;

    return 'Untitled Conversation';
  }

  function toAbsoluteUrl(href) {
    try {
      return new URL(href, window.location.origin).toString();
    } catch {
      return window.location.origin;
    }
  }

  function readConversation(anchor) {
    const href = normalizeHref(anchor.getAttribute('href') || '');
    const conversationId = extractConversationIdFromUrl(href);
    if (!conversationId) return null;

    return {
      conversationId,
      title: getConversationTitleFromAnchor(anchor),
      url: toAbsoluteUrl(href)
    };
  }

  function scanConversations() {
    return gatherCandidateAnchors()
      .map((anchor) => {
        const conversation = readConversation(anchor);
        if (!conversation) return null;
        return { anchor, conversation };
      })
      .filter((item) => item !== null);
  }

  function scoreSidebarContainer(container) {
    if (!container) return 0;

    let score = 0;

    const anchors = container.querySelectorAll('a[href*="/c/"]').length;
    if (anchors > 0) score += anchors * 8;

    if (container.tagName === 'NAV') score += 40;
    if (container.tagName === 'ASIDE') score += 30;

    const ariaLabel = (container.getAttribute('aria-label') || '').toLowerCase();
    if (hasConversationHint(ariaLabel)) {
      score += 35;
    }

    const testId = (container.getAttribute('data-testid') || '').toLowerCase();
    if (hasConversationHint(testId) || testId.includes('sidebar')) {
      score += 28;
    }

    const className = container.className;
    if (typeof className === 'string' && hasConversationHint(className)) {
      score += 18;
    }

    const role = (container.getAttribute('role') || '').toLowerCase();
    if (role === 'navigation' || role === 'complementary') {
      score += 15;
    }

    return score;
  }

  function getSidebarContainer() {
    const scanned = scanConversations();

    if (scanned.length > 0) {
      const candidates = [];
      scanned.forEach(({ anchor }) => {
        const nav = anchor.closest('nav');
        const aside = anchor.closest('aside');
        const roleNav = anchor.closest('[role="navigation"]');
        const complementary = anchor.closest('[role="complementary"]');
        const testHistory = anchor.closest('[data-testid*="history"]');
        const testSidebar = anchor.closest('[data-testid*="sidebar"]');
        const parent = anchor.parentElement;

        [nav, aside, roleNav, complementary, testHistory, testSidebar, parent].forEach((candidate) => {
          if (candidate && !candidates.includes(candidate)) {
            candidates.push(candidate);
          }
        });
      });

      candidates.sort((a, b) => scoreSidebarContainer(b) - scoreSidebarContainer(a));
      if (candidates[0]) return candidates[0];
    }

    const fallbackCandidates = [];
    CONTAINER_CANDIDATE_SELECTORS.forEach((selector) => {
      const node = document.querySelector(selector);
      if (node instanceof HTMLElement && !fallbackCandidates.includes(node)) {
        fallbackCandidates.push(node);
      }
    });

    if (fallbackCandidates.length === 0) {
      return null;
    }

    fallbackCandidates.sort((a, b) => scoreSidebarContainer(b) - scoreSidebarContainer(a));
    return fallbackCandidates[0] || null;
  }

  function hasRecentLabel(text) {
    const normalized = String(text || '').trim().toLowerCase();
    if (!normalized) return false;
    return RECENTS_LABELS.some((label) => normalized.includes(label));
  }

  function getRecentSectionAnchor(sidebar) {
    if (!(sidebar instanceof HTMLElement)) return null;

    const selectors = ['h1', 'h2', 'h3', 'h4', '[role="heading"]', 'div', 'span'];
    for (const selector of selectors) {
      const nodes = Array.from(sidebar.querySelectorAll(selector));
      for (const node of nodes) {
        if (!(node instanceof HTMLElement)) continue;
        if (node.closest(`#${window.CGV.constants.appRootId}`)) continue;

        const text = (node.textContent || '').trim();
        if (!hasRecentLabel(text)) continue;

        const sectionLike =
          node.closest('[data-testid*="history"]') ||
          node.closest('section') ||
          node.closest('[role="region"]') ||
          node.parentElement;

        if (sectionLike instanceof HTMLElement) {
          return sectionLike;
        }
      }
    }

    return null;
  }

  function getActiveConversationId() {
    const pathname = window.location.pathname || '';
    const match = pathname.match(window.CGV.constants.conversationUrlPattern);
    return match ? match[1] : null;
  }

  function makeNativeConversationDraggable(anchor, conversation, onDragStart) {
    if (!anchor || !conversation || typeof onDragStart !== 'function') return;

    const row =
      anchor.closest('[data-testid*="history-item"]') ||
      anchor.closest('li') ||
      anchor.closest('[role="listitem"]') ||
      anchor.closest('div') ||
      anchor;

    if (!(row instanceof HTMLElement)) return;

    if (row.dataset.cgvDragBound === '1') return;
    row.dataset.cgvDragBound = '1';
    row.setAttribute('draggable', 'true');

    row.addEventListener('dragstart', (event) => {
      onDragStart(event, conversation);
    });
  }

  function observeApp(onChange) {
    if (typeof onChange !== 'function') {
      return () => {};
    }

    let lastPath = window.location.pathname;
    let scheduled = false;

    const schedule = () => {
      if (scheduled) return;
      scheduled = true;
      window.setTimeout(() => {
        scheduled = false;
        onChange();
      }, 80);
    };

    const observer = new MutationObserver(() => {
      if (window.location.pathname !== lastPath) {
        lastPath = window.location.pathname;
      }
      schedule();
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });

    const onPopState = () => schedule();
    window.addEventListener('popstate', onPopState);

    const interval = window.setInterval(() => {
      if (window.location.pathname !== lastPath) {
        lastPath = window.location.pathname;
        schedule();
      }
    }, 1000);

    return () => {
      observer.disconnect();
      window.removeEventListener('popstate', onPopState);
      window.clearInterval(interval);
    };
  }

  window.CGV.chatgptAdapter = {
    extractConversationIdFromUrl,
    scanConversations,
    getSidebarContainer,
    getRecentSectionAnchor,
    getActiveConversationId,
    makeNativeConversationDraggable,
    observeApp
  };
})();
