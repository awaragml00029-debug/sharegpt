(() => {
  'use strict';

  window.CGV = window.CGV || {};

  const textEncoder = new TextEncoder();

  const CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i += 1) {
      let value = i;
      for (let j = 0; j < 8; j += 1) {
        if ((value & 1) === 1) {
          value = 0xedb88320 ^ (value >>> 1);
        } else {
          value >>>= 1;
        }
      }
      table[i] = value >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i += 1) {
      const tableIndex = (crc ^ bytes[i]) & 0xff;
      crc = CRC_TABLE[tableIndex] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function sanitizeEntryName(name) {
    const value = String(name || 'file.txt').replace(/\\+/g, '/').replace(/\/+/, '/').trim();
    const parts = value
      .split('/')
      .map((part) => part.trim())
      .filter((part) => part && part !== '.' && part !== '..')
      .map((part) => {
        const withoutReserved = part.replace(/[<>:"|?*]/g, '_');
        return withoutReserved.replaceAll('\u0000', '_');
      });

    if (parts.length === 0) {
      return 'file.txt';
    }

    return parts.join('/').slice(0, 240);
  }

  function toBytes(content) {
    if (content instanceof Uint8Array) {
      return content;
    }

    if (content instanceof ArrayBuffer) {
      return new Uint8Array(content);
    }

    return textEncoder.encode(String(content ?? ''));
  }

  function createDosTimestamp(date) {
    const value = date instanceof Date ? date : new Date();
    const year = Math.min(Math.max(value.getFullYear(), 1980), 2107);
    const month = value.getMonth() + 1;
    const day = value.getDate();
    const hours = value.getHours();
    const minutes = value.getMinutes();
    const seconds = Math.floor(value.getSeconds() / 2);

    const dosDate = ((year - 1980) << 9) | (month << 5) | day;
    const dosTime = (hours << 11) | (minutes << 5) | seconds;

    return { dosDate, dosTime };
  }

  function createLocalHeader(fileNameBytes, metadata) {
    const buffer = new Uint8Array(30 + fileNameBytes.length);
    const view = new DataView(buffer.buffer);

    view.setUint32(0, 0x04034b50, true); // local file header signature
    view.setUint16(4, 20, true); // version needed to extract
    view.setUint16(6, 0, true); // general purpose bit flag
    view.setUint16(8, 0, true); // compression method (store)
    view.setUint16(10, metadata.dosTime, true);
    view.setUint16(12, metadata.dosDate, true);
    view.setUint32(14, metadata.crc, true);
    view.setUint32(18, metadata.size, true); // compressed size
    view.setUint32(22, metadata.size, true); // uncompressed size
    view.setUint16(26, fileNameBytes.length, true);
    view.setUint16(28, 0, true); // extra field length

    buffer.set(fileNameBytes, 30);

    return buffer;
  }

  function createCentralHeader(fileNameBytes, metadata, offset) {
    const buffer = new Uint8Array(46 + fileNameBytes.length);
    const view = new DataView(buffer.buffer);

    view.setUint32(0, 0x02014b50, true); // central directory signature
    view.setUint16(4, 20, true); // version made by
    view.setUint16(6, 20, true); // version needed
    view.setUint16(8, 0, true); // general purpose bit flag
    view.setUint16(10, 0, true); // compression method
    view.setUint16(12, metadata.dosTime, true);
    view.setUint16(14, metadata.dosDate, true);
    view.setUint32(16, metadata.crc, true);
    view.setUint32(20, metadata.size, true);
    view.setUint32(24, metadata.size, true);
    view.setUint16(28, fileNameBytes.length, true);
    view.setUint16(30, 0, true); // extra length
    view.setUint16(32, 0, true); // file comment length
    view.setUint16(34, 0, true); // disk number start
    view.setUint16(36, 0, true); // internal attrs
    view.setUint32(38, 0, true); // external attrs
    view.setUint32(42, offset, true); // relative offset local header

    buffer.set(fileNameBytes, 46);

    return buffer;
  }

  function createEndOfCentralDirectory(recordCount, centralSize, centralOffset) {
    const buffer = new Uint8Array(22);
    const view = new DataView(buffer.buffer);

    view.setUint32(0, 0x06054b50, true); // end central dir signature
    view.setUint16(4, 0, true); // number of this disk
    view.setUint16(6, 0, true); // disk where central directory starts
    view.setUint16(8, recordCount, true); // records on this disk
    view.setUint16(10, recordCount, true); // total records
    view.setUint32(12, centralSize, true);
    view.setUint32(16, centralOffset, true);
    view.setUint16(20, 0, true); // comment length

    return buffer;
  }

  function createZipBlob(entries) {
    const safeEntries = Array.isArray(entries) ? entries : [];

    const localChunks = [];
    const centralChunks = [];

    let localOffset = 0;

    for (let i = 0; i < safeEntries.length; i += 1) {
      const entry = safeEntries[i] || {};
      const fileName = sanitizeEntryName(entry.name || `file-${i + 1}.txt`);
      const fileNameBytes = textEncoder.encode(fileName);
      const data = toBytes(entry.content);

      const timestamp = createDosTimestamp(entry.date);
      const metadata = {
        dosDate: timestamp.dosDate,
        dosTime: timestamp.dosTime,
        crc: crc32(data),
        size: data.length,
      };

      const localHeader = createLocalHeader(fileNameBytes, metadata);
      const centralHeader = createCentralHeader(fileNameBytes, metadata, localOffset);

      localChunks.push(localHeader, data);
      centralChunks.push(centralHeader);

      localOffset += localHeader.length + data.length;
    }

    const centralOffset = localOffset;
    let centralSize = 0;
    for (let i = 0; i < centralChunks.length; i += 1) {
      centralSize += centralChunks[i].length;
    }

    const endRecord = createEndOfCentralDirectory(centralChunks.length, centralSize, centralOffset);

    return new Blob([...localChunks, ...centralChunks, endRecord], {
      type: 'application/zip',
    });
  }

  function downloadZip(entries, filename) {
    const zipBlob = createZipBlob(entries);
    const objectUrl = URL.createObjectURL(zipBlob);

    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = filename || 'export.zip';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(objectUrl);
  }

  window.CGV.zip = {
    sanitizeEntryName,
    createZipBlob,
    downloadZip,
  };
})();
