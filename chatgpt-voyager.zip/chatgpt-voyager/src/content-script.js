(() => {
  'use strict';

  if (window.__chatgptVoyagerLoaded) {
    return;
  }
  window.__chatgptVoyagerLoaded = true;

  async function boot() {
    const data = await window.CGV.storage.load();
    const state = {
      data,
      statusEl: null,
      editingFolderId: null,
      deletePendingFolderId: null,
      teardown: null
    };

    state.teardown = window.CGV.ui.init(state);
  }

  boot().catch(() => {
    // silent fail to avoid breaking host page
  });
})();
